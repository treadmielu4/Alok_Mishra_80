/**
 * 
 */
/**
 * @author 835027
 *
 */
package com.stock.model;